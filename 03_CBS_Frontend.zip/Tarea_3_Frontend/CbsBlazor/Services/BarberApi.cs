using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;

namespace CbsBlazor.Services;

// Servicio por circuito: todas las pantallas consumen la API REST.
public class BarberApi(HttpClient http, Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage.ProtectedSessionStorage storage)
{
    public bool IsLoggedIn { get; private set; }

    public async Task Login(string user, string password)
    {
        Logout();
        using var response = await http.PostAsJsonAsync("api/auth/login", new { email = user, password });
        await Check(response);
        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var token = json.RootElement.GetProperty("token").GetString()
            ?? throw new InvalidOperationException("La API no devolvió un token.");
        http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        await storage.SetAsync("cbs-token", token);
        IsLoggedIn = true;
    }

    public async Task<bool> Restore()
    {
        if (IsLoggedIn) return true;
        var saved = await storage.GetAsync<string>("cbs-token");
        if (!saved.Success || string.IsNullOrEmpty(saved.Value)) return false;
        http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", saved.Value);
        using var response = await http.GetAsync("api/auth/me");
        if (!response.IsSuccessStatusCode) { await LogoutStored(); return false; }
        IsLoggedIn = true;
        return true;
    }

    public async Task LogoutStored()
    {
        Logout();
        await storage.DeleteAsync("cbs-token");
    }

    public void Logout()
    {
        IsLoggedIn = false;
        http.DefaultRequestHeaders.Authorization = null;
    }

    public async Task<List<T>> List<T>(string route)
    {
        using var response = await http.GetAsync("api/" + route);
        await Check(response);
        return await response.Content.ReadFromJsonAsync<List<T>>() ?? [];
    }

    public async Task Save<T>(string route, long id, T model)
    {
        using var response = id == 0
            ? await http.PostAsJsonAsync("api/" + route, model)
            : await http.PutAsJsonAsync("api/" + route + "/" + id, model);
        await Check(response);
    }

    public async Task Delete(string route, long id)
    {
        using var response = await http.DeleteAsync("api/" + route + "/" + id);
        await Check(response);
    }

    public async Task State(long id, string estado)
    {
        using var response = await http.PatchAsJsonAsync(
            $"api/citas/{id}/estado", new { estado });
        await Check(response);
    }

    public Task SaveAppointment(CitaForm form) => Save("citas", form.Id, new
    {
        form.ClienteId,
        form.BarberoId,
        form.ServicioId,
        fecha = form.Fecha.ToString("yyyy-MM-dd"),
        hora = form.Hora,
        notas = form.Notas
    });

    private static async Task Check(HttpResponseMessage response)
    {
        if (response.IsSuccessStatusCode) return;
        string message = response.StatusCode == System.Net.HttpStatusCode.Unauthorized
            ? "Credenciales incorrectas. Inicia sesión nuevamente."
            : "No se pudo completar la operación.";
        try
        {
            using var json = JsonDocument.Parse(
                await response.Content.ReadAsStringAsync());
            if (json.RootElement.TryGetProperty("mensaje", out var value))
                message = value.GetString() ?? message;
        }
        catch (JsonException) { }
        throw new InvalidOperationException(message);
    }
}
