using CbsApi.Models;
using CbsApi.DTOs;
namespace CbsApi.Mappings;
// Mapeo explícito para mantener DTO de entrada separado de entidades persistidas.
public static class MappingProfile  {
    public static void Apply(this ClienteRequest d, Cliente e)  {
        e.Nombre=d.Nombre.Trim();
        e.Telefono=d.Telefono.Trim();
        e.Email=d.Email;
    }
    public static void Apply(this BarberoRequest d, Barbero e)  {
        e.Nombre=d.Nombre.Trim();
        e.Especialidad=d.Especialidad.Trim();
        e.Activo=d.Activo;
    }
    public static void Apply(this ServicioRequest d, Servicio e)  {
        e.Nombre=d.Nombre.Trim();
        e.Precio=d.Precio;
        e.DuracionMinutos=d.DuracionMinutos;
    }
}
