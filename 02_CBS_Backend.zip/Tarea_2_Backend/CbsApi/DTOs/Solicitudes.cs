using System.ComponentModel.DataAnnotations;
namespace CbsApi.DTOs;
public class ClienteRequest  {
    [Required, StringLength(100)] public string Nombre  { get; set; } ="";
    [Required, RegularExpression(@"[+0-9 ()-]{8,20}")] public string Telefono  { get; set; } ="";
    [EmailAddress, StringLength(150)] public string? Email  { get; set; }
}
public class BarberoRequest  {
    [Required, StringLength(100)] public string Nombre  { get; set; } ="";
    [Required, StringLength(100)] public string Especialidad  { get; set; } ="";
    public bool Activo  { get; set; } =true;
}
public class ServicioRequest  {
    [Required, StringLength(100)] public string Nombre  { get; set; } ="";
    [Range(0.01,999999)] public decimal Precio  { get; set; }
[Range(15,180)] public int DuracionMinutos  { get; set; }
}
public class CitaRequest  {
    [Range(1,long.MaxValue)] public long ClienteId  { get; set; }
[Range(1,long.MaxValue)] public long BarberoId  { get; set; }
[Range(1,long.MaxValue)] public long ServicioId  { get; set; }
public DateOnly Fecha  { get; set; }
public TimeOnly Hora  { get; set; }
[StringLength(250)] public string? Notas  { get; set; }
}
public record EstadoRequest(string Estado);
public record LoginRequest(string Email, string Password);
public record LoginResponse(string Token, DateTime Expira, string Email, string Rol);
