using Microsoft.EntityFrameworkCore;
namespace CbsApi.Models;
public class BarberDbContext(DbContextOptions<BarberDbContext> options) : DbContext(options)  {
    public DbSet<Cliente> Clientes => Set<Cliente>();
    public DbSet<Barbero> Barberos => Set<Barbero>();
    public DbSet<Servicio> Servicios => Set<Servicio>();
    public DbSet<Cita> Citas => Set<Cita>();
    public DbSet<Usuario> Usuarios => Set<Usuario>();
    protected override void OnModelCreating(ModelBuilder m)  {
        m.Entity<Usuario>().HasIndex(x=>x.Email).IsUnique();
        m.Entity<Servicio>().Property(x=>x.Precio).HasPrecision(10,2);
        m.Entity<Cita>().Property(x=>x.Precio).HasPrecision(10,2);
        m.Entity<Cita>().HasOne(x=>x.Cliente).WithMany().HasForeignKey(x=>x.ClienteId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Cita>().HasOne(x=>x.Barbero).WithMany().HasForeignKey(x=>x.BarberoId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Cita>().HasOne(x=>x.Servicio).WithMany().HasForeignKey(x=>x.ServicioId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Cita>().HasIndex(x=>new {
            x.BarberoId,x.Fecha
        });
    }
}
