namespace CbsApi.Models;
public class Cliente  {
    public long Id  { get; set; }
public string Nombre  { get; set; } ="";
    public string Telefono  { get; set; } ="";
    public string? Email  { get; set; }
}
public class Barbero  {
    public long Id  { get; set; }
public string Nombre  { get; set; } ="";
    public string Especialidad  { get; set; } ="";
    public bool Activo  { get; set; } =true;
}
public class Servicio  {
    public long Id  { get; set; }
public string Nombre  { get; set; } ="";
    public decimal Precio  { get; set; }
public int DuracionMinutos  { get; set; }
}
public class Usuario  {
    public long Id  { get; set; }
public string Email  { get; set; } ="";
    public string PasswordHash  { get; set; } ="";
    public string Rol  { get; set; } ="ADMIN";
}
public class Cita  {
    public long Id  { get; set; }
public long ClienteId  { get; set; }
public Cliente Cliente  { get; set; } =null!;
    public long BarberoId  { get; set; }
public Barbero Barbero  { get; set; } =null!;
    public long ServicioId  { get; set; }
public Servicio Servicio  { get; set; } =null!;
    public DateOnly Fecha  { get; set; }
public TimeOnly Hora  { get; set; }
public string Estado  { get; set; } ="PENDIENTE";
    public decimal Precio  { get; set; }
public int DuracionMinutos  { get; set; }
public string? Notas  { get; set; }
}
