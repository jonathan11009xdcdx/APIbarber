using CbsApi.Models;
using CbsApi.Services;
using CbsApi.Endpoints;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;
var builder=WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<BarberDbContext>(o=>  {
    if(builder.Configuration["Database:Provider"]=="SqlServer")o.UseSqlServer(builder.Configuration.GetConnectionString("SqlServer"));
    else o.UseSqlite(builder.Configuration.GetConnectionString("Sqlite"));
});
builder.Services.AddScoped<IAgendaService,AgendaService>();
builder.Services.AddScoped<AuthService>();
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o=>  {
    o.TokenValidationParameters=new TokenValidationParameters  {
        ValidateIssuer=true,ValidateAudience=true,ValidateLifetime=true,ValidateIssuerSigningKey=true,
        ValidIssuer=builder.Configuration["Jwt:Issuer"],ValidAudience=builder.Configuration["Jwt:Audience"],
        IssuerSigningKey=new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!)),ClockSkew=TimeSpan.FromSeconds(10)
    };
});
builder.Services.AddAuthorization();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o=>  {
    o.AddSecurityDefinition("Bearer",new OpenApiSecurityScheme  {
        Type=SecuritySchemeType.Http,Scheme="bearer",BearerFormat="JWT",Description="Pega el token de /api/auth/login."
    });
    o.AddSecurityRequirement(new OpenApiSecurityRequirement  {
        {
            new OpenApiSecurityScheme  {
                Reference=new OpenApiReference  {
                    Type=ReferenceType.SecurityScheme,Id="Bearer"
                }
            },Array.Empty<string>()
        }
    });
});
var app=builder.Build();
app.Use(async(ctx,next)=>  {
    try  {
        await next();
    }
    catch(ReglaException ex) {
        ctx.Response.StatusCode=ex.Status;await ctx.Response.WriteAsJsonAsync(new {
            mensaje=ex.Message
        });
    }
    catch(DbUpdateException) {
        ctx.Response.StatusCode=409;await ctx.Response.WriteAsJsonAsync(new {
            mensaje="No se pudo guardar: conflicto de datos."
        });
    }
});
app.UseSwagger();
app.UseSwaggerUI();
app.UseAuthentication();
app.UseAuthorization();
app.UseEndpoints();
using(var scope=app.Services.CreateScope())  {
    var db=scope.ServiceProvider.GetRequiredService<BarberDbContext>();
    if (builder.Configuration["GenerarSql"] is { } sqlPath)
    {
        File.WriteAllText(sqlPath, db.Database.GenerateCreateScript());
        return;
    }
    db.Database.EnsureCreated();
    if(!db.Usuarios.Any())  {
        var u=new Usuario  {
            Email="admin@coolbarbershop.com"
        };
        u.PasswordHash=new PasswordHasher<Usuario>().HashPassword(u,"Admin123!");
        db.Usuarios.Add(u);
    }
    if(!db.Clientes.Any())db.Clientes.Add(new Cliente  {
        Nombre="Cliente demostración",Telefono="7000-0000",Email="cliente@example.com"
    });
    if(!db.Barberos.Any())db.Barberos.AddRange(new Barbero  {
        Nombre="Carlos Méndez",Especialidad="Cortes clásicos"
    },new Barbero  {
        Nombre="Luis Hernández",Especialidad="Barba y degradados"
    });
    if(!db.Servicios.Any())db.Servicios.AddRange(new Servicio  {
        Nombre="Corte de cabello",Precio=6,DuracionMinutos=30
    },new Servicio  {
        Nombre="Corte y barba",Precio=10,DuracionMinutos=45
    });
    db.SaveChanges();
}
app.Run();
