using CbsApi.Models;
using CbsApi.DTOs;
using CbsApi.Mappings;
using CbsApi.Services;
using Microsoft.EntityFrameworkCore;
namespace CbsApi.Endpoints;
public static class ServicioEndpoints  {
    public static void MapServicios(this WebApplication app)  {
        var group=app.MapGroup("/api/servicios").WithTags("Servicios").RequireAuthorization();
        group.MapGet("/",async (BarberDbContext db)=>Results.Ok(await db.Servicios.OrderBy(x=>x.Id).ToListAsync()));
        group.MapGet("/{id:long}",async (long id,BarberDbContext db)=>await db.Servicios.FindAsync(id) is  {
        }
        item?Results.Ok(item):Results.NotFound());
        group.MapPost("/",async (ServicioRequest request,BarberDbContext db)=> {
            Reglas.Validar(request);var entity=new Servicio();request.Apply(entity);db.Servicios.Add(entity);await db.SaveChangesAsync();return Results.Created($"/api/servicios/{entity.Id}",entity);
        });
        group.MapPut("/{id:long}",async (long id,ServicioRequest request,BarberDbContext db)=> {
            Reglas.Validar(request);var entity=await db.Servicios.FindAsync(id);if(entity==null)return Results.NotFound();request.Apply(entity);await db.SaveChangesAsync();return Results.Ok(entity);
        });
        group.MapDelete("/{id:long}",async (long id,BarberDbContext db)=> {
            var entity=await db.Servicios.FindAsync(id);if(entity==null)return Results.NotFound();
            if(await db.Citas.AnyAsync(x=>x.ServicioId==id))throw new ReglaException(409,"No se puede eliminar: tiene citas asociadas.");
            db.Servicios.Remove(entity);await db.SaveChangesAsync();return Results.NoContent();
        });
    }
}
