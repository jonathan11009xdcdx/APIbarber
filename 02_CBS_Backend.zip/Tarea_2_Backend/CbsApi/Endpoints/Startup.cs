using CbsApi.DTOs;
using CbsApi.Services;
namespace CbsApi.Endpoints;
public static class Startup  {
    public static void UseEndpoints(this WebApplication app)  {
        app.MapClientes();
        app.MapBarberos();
        app.MapServicios();
        app.MapGet("/api/salud",()=>Results.Ok(new  {
            estado="OK",aplicacion="CBS Minimal API"
        }));
        app.MapPost("/api/auth/login",async(LoginRequest request,AuthService service)=>
        await service.Login(request) is  {
        }
        login?Results.Ok(login):Results.Unauthorized()).WithTags("Autenticación");
        app.MapGet("/api/auth/me",(System.Security.Claims.ClaimsPrincipal user)=>Results.Ok(new  {
            email=user.Identity?.Name
        })).RequireAuthorization();
        var group=app.MapGroup("/api/citas").WithTags("Citas").RequireAuthorization();
        group.MapGet("/",async(IAgendaService service)=>Results.Ok(await service.Listar()));
        group.MapGet("/{id:long}",async(long id,IAgendaService service)=>Results.Ok(await service.Obtener(id)));
        group.MapPost("/",async(CitaRequest request,IAgendaService service)=>  {
            var c=await service.Guardar(0,request);return Results.Created($"/api/citas/{c.Id}",c);
        });
        group.MapPut("/{id:long}",async(long id,CitaRequest request,IAgendaService service)=>Results.Ok(await service.Guardar(id,request)));
        group.MapPatch("/{id:long}/estado",async(long id,EstadoRequest request,IAgendaService service)=>Results.Ok(await service.CambiarEstado(id,request.Estado)));
    }
}
