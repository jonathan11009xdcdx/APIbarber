using CbsApi.Models;
using CbsApi.DTOs;
using CbsApi.Mappings;
using CbsApi.Services;
using Microsoft.EntityFrameworkCore;
namespace CbsApi.Endpoints;
public static class ClienteEndpoints  {
    public static void MapClientes(this WebApplication app)  {
        var group=app.MapGroup("/api/clientes").WithTags("Clientes").RequireAuthorization();
        group.MapGet("/",async (BarberDbContext db)=>Results.Ok(await db.Clientes.OrderBy(x=>x.Id).ToListAsync()));
        group.MapGet("/{id:long}",async (long id,BarberDbContext db)=>await db.Clientes.FindAsync(id) is  {
        }
        item?Results.Ok(item):Results.NotFound());
        group.MapPost("/",async (ClienteRequest request,BarberDbContext db)=> {
            Reglas.Validar(request);var entity=new Cliente();request.Apply(entity);db.Clientes.Add(entity);await db.SaveChangesAsync();return Results.Created($"/api/clientes/{entity.Id}",entity);
        });
        group.MapPut("/{id:long}",async (long id,ClienteRequest request,BarberDbContext db)=> {
            Reglas.Validar(request);var entity=await db.Clientes.FindAsync(id);if(entity==null)return Results.NotFound();request.Apply(entity);await db.SaveChangesAsync();return Results.Ok(entity);
        });
        group.MapDelete("/{id:long}",async (long id,BarberDbContext db)=> {
            var entity=await db.Clientes.FindAsync(id);if(entity==null)return Results.NotFound();
            if(await db.Citas.AnyAsync(x=>x.ClienteId==id))throw new ReglaException(409,"No se puede eliminar: tiene citas asociadas.");
            db.Clientes.Remove(entity);await db.SaveChangesAsync();return Results.NoContent();
        });
    }
}
