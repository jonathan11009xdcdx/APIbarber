using CbsApi.Models;
using CbsApi.DTOs;
using CbsApi.Mappings;
using CbsApi.Services;
using Microsoft.EntityFrameworkCore;
namespace CbsApi.Endpoints;
public static class BarberoEndpoints  {
    public static void MapBarberos(this WebApplication app)  {
        var group=app.MapGroup("/api/barberos").WithTags("Barberos").RequireAuthorization();
        group.MapGet("/",async (BarberDbContext db)=>Results.Ok(await db.Barberos.OrderBy(x=>x.Id).ToListAsync()));
        group.MapGet("/{id:long}",async (long id,BarberDbContext db)=>await db.Barberos.FindAsync(id) is  {
        }
        item?Results.Ok(item):Results.NotFound());
        group.MapPost("/",async (BarberoRequest request,BarberDbContext db)=> {
            Reglas.Validar(request);var entity=new Barbero();request.Apply(entity);db.Barberos.Add(entity);await db.SaveChangesAsync();return Results.Created($"/api/barberos/{entity.Id}",entity);
        });
        group.MapPut("/{id:long}",async (long id,BarberoRequest request,BarberDbContext db)=> {
            Reglas.Validar(request);var entity=await db.Barberos.FindAsync(id);if(entity==null)return Results.NotFound();request.Apply(entity);await db.SaveChangesAsync();return Results.Ok(entity);
        });
        group.MapDelete("/{id:long}",async (long id,BarberDbContext db)=> {
            var entity=await db.Barberos.FindAsync(id);if(entity==null)return Results.NotFound();
            if(await db.Citas.AnyAsync(x=>x.BarberoId==id))throw new ReglaException(409,"No se puede eliminar: tiene citas asociadas.");
            db.Barberos.Remove(entity);await db.SaveChangesAsync();return Results.NoContent();
        });
    }
}
