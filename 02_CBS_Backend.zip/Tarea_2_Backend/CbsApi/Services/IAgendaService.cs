using CbsApi.Models;
using CbsApi.DTOs;
namespace CbsApi.Services;
public interface IAgendaService  {
    Task<List<Cita>> Listar();
    Task<Cita> Obtener(long id);
    Task<Cita> Guardar(long id,CitaRequest request);
    Task<Cita> CambiarEstado(long id,string estado);
}
