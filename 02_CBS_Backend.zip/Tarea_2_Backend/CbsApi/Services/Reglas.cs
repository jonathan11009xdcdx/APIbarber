using System.ComponentModel.DataAnnotations;
namespace CbsApi.Services;
public class ReglaException(int status,string message) : Exception(message)  {
    public int Status  {
        get;
    }
    =status;
}
public static class Reglas  {
    public static void Validar(object request)  {
        var errors=new List<ValidationResult>();
        if(!Validator.TryValidateObject(request,new ValidationContext(request),errors,true))
        throw new ReglaException(400,string.Join(" ",errors.Select(x=>x.ErrorMessage)));
    }
}
