using CbsApi.Models;
using CbsApi.DTOs;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
namespace CbsApi.Services;
public class AuthService(BarberDbContext db,IConfiguration config)  {
    public async Task<LoginResponse?> Login(LoginRequest request)  {
        if(string.IsNullOrWhiteSpace(request.Email)||string.IsNullOrWhiteSpace(request.Password)) return null;
        var u=await db.Usuarios.FirstOrDefaultAsync(x=>x.Email==request.Email.Trim().ToLower());
        if(u==null || new PasswordHasher<Usuario>().VerifyHashedPassword(u,u.PasswordHash,request.Password)==PasswordVerificationResult.Failed) return null;
        var expires=DateTime.UtcNow.AddHours(2);
        var token=new JwtSecurityToken(config["Jwt:Issuer"],config["Jwt:Audience"],
        [new Claim(ClaimTypes.Name,u.Email),new Claim(ClaimTypes.Role,u.Rol)],expires:expires,
        signingCredentials:new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!)),SecurityAlgorithms.HmacSha256));
        return new LoginResponse(new JwtSecurityTokenHandler().WriteToken(token),expires,u.Email,u.Rol);
    }
}
