using CbsApi.Models;
using CbsApi.DTOs;
using Microsoft.EntityFrameworkCore;
using System.Data;
namespace CbsApi.Services;
public class AgendaService(BarberDbContext db, IConfiguration config) : IAgendaService  {
    // Un servidor de demostración: serializa las escrituras de citas.
    // La transacción serializable también protege la operación de base de datos.
    private static readonly SemaphoreSlim Gate=new(1,1);
    private IQueryable<Cita> Consulta()=>db.Citas.Include(x=>x.Cliente).Include(x=>x.Barbero).Include(x=>x.Servicio);
    public Task<List<Cita>> Listar()=>Consulta().OrderBy(x=>x.Fecha).ThenBy(x=>x.Hora).ToListAsync();
    public async Task<Cita> Obtener(long id)=>await Consulta().FirstOrDefaultAsync(x=>x.Id==id) ?? throw new ReglaException(404,"Cita no encontrada.");
    public async Task<Cita> Guardar(long id,CitaRequest request)  {
        Reglas.Validar(request);
        await Gate.WaitAsync();
        try  {
            await using var transaction=await db.Database.BeginTransactionAsync(IsolationLevel.Serializable);
            var cita=id==0?new Cita():await Obtener(id);
            if(cita.Estado is "CANCELADA" or "COMPLETADA") throw new ReglaException(409,"La cita ya tiene un estado final.");
            var cliente=await db.Clientes.FindAsync(request.ClienteId) ?? throw new ReglaException(404,"Cliente no encontrado.");
            var barbero=await db.Barberos.FindAsync(request.BarberoId) ?? throw new ReglaException(404,"Barbero no encontrado.");
            var servicio=await db.Servicios.FindAsync(request.ServicioId) ?? throw new ReglaException(404,"Servicio no encontrado.");
            if(!barbero.Activo) throw new ReglaException(400,"El barbero no está activo.");
            var now=TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow,TimeZoneInfo.FindSystemTimeZoneById(config["Agenda:ZonaHoraria"] ?? "America/El_Salvador")).DateTime;
            if(request.Fecha.ToDateTime(request.Hora)<=now) throw new ReglaException(400,"Selecciona una fecha y hora futuras.");
            int duration=id!=0 && cita.ServicioId==servicio.Id?cita.DuracionMinutos:servicio.DuracionMinutos;
            var start=request.Hora.ToTimeSpan();
            var end=start+TimeSpan.FromMinutes(duration);
            if(request.Fecha.DayOfWeek==DayOfWeek.Sunday || start<TimeSpan.FromHours(8) || end>TimeSpan.FromHours(18) || request.Hora.Minute%15!=0 || request.Hora.Second!=0)
            throw new ReglaException(400,"Horario: lunes a sábado, 08:00 a 18:00; intervalos de 15 minutos.");
            var sameDay=await db.Citas.Where(x=>x.Id!=id && x.BarberoId==barbero.Id && x.Fecha==request.Fecha && x.Estado!="CANCELADA").ToListAsync();
            if(sameDay.Any(x=>start<x.Hora.ToTimeSpan()+TimeSpan.FromMinutes(x.DuracionMinutos) && end>x.Hora.ToTimeSpan()))
            throw new ReglaException(409,"El barbero ya tiene una cita en ese horario.");
            bool preserve=id!=0 && cita.ServicioId==servicio.Id;
            cita.ClienteId=cliente.Id;
            cita.BarberoId=barbero.Id;
            cita.ServicioId=servicio.Id;
            cita.Fecha=request.Fecha;
            cita.Hora=request.Hora;
            cita.Notas=request.Notas;
            if(!preserve) {
                cita.Precio=servicio.Precio;
                cita.DuracionMinutos=duration;
            }
            if(id==0) db.Citas.Add(cita);
            await db.SaveChangesAsync();
            await transaction.CommitAsync();
            return await Obtener(cita.Id);
        }
        finally  {
            Gate.Release();
        }
    }
    public async Task<Cita> CambiarEstado(long id,string estado)  {
        await Gate.WaitAsync();
        try  {
            var c=await Obtener(id);
            estado=estado?.ToUpperInvariant() ?? "";
            bool allowed=(c.Estado=="PENDIENTE" && estado is "CONFIRMADA" or "CANCELADA") || (c.Estado=="CONFIRMADA" && estado is "COMPLETADA" or "CANCELADA");
            if(!allowed) throw new ReglaException(409,"Transición de estado no permitida.");
            c.Estado=estado;
            await db.SaveChangesAsync();
            return c;
        }
        finally  {
            Gate.Release();
        }
    }
}
