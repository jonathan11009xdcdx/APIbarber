CREATE TABLE [Barberos] (
    [Id] bigint NOT NULL IDENTITY,
    [Nombre] nvarchar(max) NOT NULL,
    [Especialidad] nvarchar(max) NOT NULL,
    [Activo] bit NOT NULL,
    CONSTRAINT [PK_Barberos] PRIMARY KEY ([Id])
);
GO


CREATE TABLE [Clientes] (
    [Id] bigint NOT NULL IDENTITY,
    [Nombre] nvarchar(max) NOT NULL,
    [Telefono] nvarchar(max) NOT NULL,
    [Email] nvarchar(max) NULL,
    CONSTRAINT [PK_Clientes] PRIMARY KEY ([Id])
);
GO


CREATE TABLE [Servicios] (
    [Id] bigint NOT NULL IDENTITY,
    [Nombre] nvarchar(max) NOT NULL,
    [Precio] decimal(10,2) NOT NULL,
    [DuracionMinutos] int NOT NULL,
    CONSTRAINT [PK_Servicios] PRIMARY KEY ([Id])
);
GO


CREATE TABLE [Usuarios] (
    [Id] bigint NOT NULL IDENTITY,
    [Email] nvarchar(450) NOT NULL,
    [PasswordHash] nvarchar(max) NOT NULL,
    [Rol] nvarchar(max) NOT NULL,
    CONSTRAINT [PK_Usuarios] PRIMARY KEY ([Id])
);
GO


CREATE TABLE [Citas] (
    [Id] bigint NOT NULL IDENTITY,
    [ClienteId] bigint NOT NULL,
    [BarberoId] bigint NOT NULL,
    [ServicioId] bigint NOT NULL,
    [Fecha] date NOT NULL,
    [Hora] time NOT NULL,
    [Estado] nvarchar(max) NOT NULL,
    [Precio] decimal(10,2) NOT NULL,
    [DuracionMinutos] int NOT NULL,
    [Notas] nvarchar(max) NULL,
    CONSTRAINT [PK_Citas] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_Citas_Barberos_BarberoId] FOREIGN KEY ([BarberoId]) REFERENCES [Barberos] ([Id]) ON DELETE NO ACTION,
    CONSTRAINT [FK_Citas_Clientes_ClienteId] FOREIGN KEY ([ClienteId]) REFERENCES [Clientes] ([Id]) ON DELETE NO ACTION,
    CONSTRAINT [FK_Citas_Servicios_ServicioId] FOREIGN KEY ([ServicioId]) REFERENCES [Servicios] ([Id]) ON DELETE NO ACTION
);
GO


CREATE INDEX [IX_Citas_BarberoId_Fecha] ON [Citas] ([BarberoId], [Fecha]);
GO


CREATE INDEX [IX_Citas_ClienteId] ON [Citas] ([ClienteId]);
GO


CREATE INDEX [IX_Citas_ServicioId] ON [Citas] ([ServicioId]);
GO


CREATE UNIQUE INDEX [IX_Usuarios_Email] ON [Usuarios] ([Email]);
GO


